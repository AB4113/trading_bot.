# engine.py
# Algorithmic Crypto/Stock Trading Bot
# Developed by Abenezer Beyene

import backtrader as bt
import yfinance as yf
from config import CONFIG
from strategy import SmaCrossoverStrategy

def run_backtest():
    print("====================================================")
    print("Algorithmic Trading Bot & Backtesting Engine")
    print("Developed by Abenezer Beyene")
    print("====================================================\n")

    cerebro = bt.Cerebro()

    # Fetch Data using yfinance
    print(f"Downloading historical data for {CONFIG['ticker']}...")
    data_df = yf.download(
        CONFIG['ticker'], 
        start=CONFIG['start_date'], 
        end=CONFIG['end_date'],
        progress=False
    )
    
    if data_df.empty:
        print("Error: No data retrieved. Check ticker or date parameters.")
        return

    # Convert to Backtrader compatible format
    data = bt.feeds.PandasData(dataname=data_df)
    cerebro.adddata(data)

    # Add Strategy
    cerebro.addstrategy(
        SmaCrossoverStrategy,
        fast_period=CONFIG['fast_period'],
        slow_period=CONFIG['slow_period']
    )

    # Broker settings
    cerebro.broker.setcash(CONFIG['initial_cash'])
    cerebro.broker.setcommission(commission=CONFIG['commission'])

    print(f"Starting Portfolio Value: ${cerebro.broker.getvalue():,.2f}")
    cerebro.run()
    print(f"Final Portfolio Value: ${cerebro.broker.getvalue():,.2f}")

if __name__ == "__main__":
    run_backtest()
