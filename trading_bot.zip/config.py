# config.py
# Algorithmic Crypto/Stock Trading Bot
# Developed by Abenezer Beyene

CONFIG = {
    "ticker": "BTC-USD",
    "start_date": "2025-01-01",
    "end_date": "2026-01-01",
    "initial_cash": 100000.0,
    "commission": 0.001,  # 0.1% transaction fee
    "fast_period": 10,
    "slow_period": 30
}
