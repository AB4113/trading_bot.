# Algorithmic Crypto/Stock Trading Bot with Backtesting Engine
**Developed by Abenezer Beyene**

An event-driven algorithmic backtesting and trading simulation platform built using Backtrader and market data wrappers.

## Project Structure
- `config.py`: Global state metrics, risk filters, asset selections, and parameter configurations.
- `strategy.py`: Logic layer for trade signal detection, portfolio position notification, and order states.
- `engine.py`: Data-feed connection coordinator and historical execution environment.

## Quick Start
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Execute the strategy pipeline:
   ```bash
   python engine.py
   ```
